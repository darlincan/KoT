pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "KingOfTokyoNeonKaiju"
include(":app")
include(":core:model")
include(":core:content")
include(":core:engine")
include(":core:ai")
include(":feature:game")
