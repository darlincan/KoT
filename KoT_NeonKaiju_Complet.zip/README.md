# King of Tokyo — Néon Kaiju

Application Android (Orientation Paysage, `minSdk 29`, JDK 21, Jetpack Compose) implémentant *King of Tokyo – Dark Edition* dans l'univers **Néon Kaiju**.

## Membres du groupe
- Darlin Canis KAPATA NGANKAM
- Adrien DEU
- Vanelle Ivanna TCHOUKA
- Ninon Carmene TSAFACK NGUEMEGNE

## Architecture Multi-Modules
- `:core:model` : Types immuables (`GameState`, `PlayerState`, `Die`, `CardDef`, `DeterministicRng`...)
- `:core:content` : Catalogue JSON (20 cartes, 10 tuiles) + interpréteur d'effets et parseur de conditions
- `:core:engine` : Moteur de règles 100 % Kotlin/JVM pur, zéro dépendance Android (`legalActions`, `reduce`)
- `:core:ai` : Politiques de décision des bots (`BotPolicy`, `HeuristicBotPolicy`)
- `:feature:game` : Thème Compose Néon Kaiju et les 7 écrans en paysage sans défilement vertical
- `:app` : Point d'entrée Android, persistance JSON versionnée et orchestration du tour des bots
